import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
            });
            const data = await res.json();
            if (res.ok) {
                login(data);
                navigate('/');
            } else {
                setError(data.error);
            }
        } catch (err) {
            setError('Error de conexión');
        }
    };

    return (
        <div className="auth-container">
            <div className="glass-panel auth-box">
                <h1 style={{ textAlign: 'center' }}>CodeForge Engineering</h1>
                <h3 style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>Iniciar Sesión</h3>
                {error && <div style={{ color: 'var(--danger)', marginBottom: '1rem', textAlign: 'center' }}>{error}</div>}
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                            placeholder="admin@uni.edu"
                            required
                        />
                    </div>
                    <div>
                        <label>Contraseña</label>
                        <input
                            type="password"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            placeholder="123"
                            required
                        />
                    </div>
                    <button type="submit" style={{ width: '100%' }}>Entrar</button>
                </form>
                <div style={{ marginTop: '1rem', fontSize: '0.8rem', color: 'var(--text-secondary)', textAlign: 'center' }}>
                    <p>Credenciales Demo:</p>
                    <p>Coord: anbaji@uni.edu / 123</p>
                    <p>Tutor: sofiaag@uni.edu / 123</p>
                    <p>Alumno: elenagl@uni.edu / 123</p>
                </div>
            </div>
        </div>
    );
}
