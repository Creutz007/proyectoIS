import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Alerts() {
    const { user } = useAuth();
    const [alerts, setAlerts] = useState([]);
    const [form, setForm] = useState({ studentId: '', type: 'ACADEMICA', description: '' });

    useEffect(() => {
        fetchAlerts();
    }, []);

    const fetchAlerts = async () => {
        const res = await fetch('/api/alerts');
        const data = await res.json();
        setAlerts(data);
    };

    const createAlert = async (e) => {
        e.preventDefault();
        await fetch('/api/alerts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...form, tutorId: user.id })
        });
        fetchAlerts();
        setForm({ studentId: '', type: 'ACADEMICA', description: '' });
    };

    return (
        <div>
            <h1>Alertas e Incidencias</h1>

            {user.role === 'TUTOR' && (
                <div className="glass-panel" style={{ borderLeft: '4px solid var(--warning)' }}>
                    <h3>Registrar Alerta</h3>
                    <form onSubmit={createAlert}>
                        <input placeholder="ID Alumno" value={form.studentId} onChange={e => setForm({ ...form, studentId: e.target.value })} />
                        <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
                            <option value="ACADEMICA">Académica</option>
                            <option value="CONDUCTA">Conducta</option>
                            <option value="OTRA">Otra</option>
                        </select>
                        <textarea placeholder="Detalle de la incidencia..." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
                        <button type="submit" style={{ background: 'var(--warning)', color: 'black' }}>Crear Alerta</button>
                    </form>
                </div>
            )}

            <div className="grid">
                {alerts.map(a => (
                    <div key={a.id} className="glass-panel" style={{ borderTop: '4px solid var(--danger)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <strong>{a.type}</strong>
                            <span style={{ fontSize: '0.8rem' }}>{new Date(a.createdAt).toLocaleDateString()}</span>
                        </div>
                        <p style={{ margin: '1rem 0' }}>{a.description}</p>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                            Alumno ID: {a.studentId} | Tutor ID: {a.tutorId}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
