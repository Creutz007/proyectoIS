import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import UserList from './users/UserList';
import Allocation from './Allocation';
import Chat from './chat/Chat';
import Minutes from './Minutes';
import Alerts from './Alerts';
import Requests from './Requests';

function Sidebar() {
    const { user, logout } = useAuth();
    const location = useLocation();
    const isActive = (path) => location.pathname === path ? 'active' : '';

    return (
        <div className="sidebar">
            <div className="logo">🎓 CodeForge Engineering</div>

            <div className="user-info" style={{ marginBottom: '2rem' }}>
                <div style={{ fontWeight: '600' }}>{user.name}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{user.role}</div>
            </div>

            <Link to="/" className={`nav-item ${isActive('/')}`}>Inicio</Link>

            {(user.role === 'COORDINADOR' || user.role === 'TUTOR') && (
                <Link to="/users" className={`nav-item ${isActive('/users')}`}>Usuarios</Link>
            )}

            {user.role === 'COORDINADOR' && (
                <Link to="/allocation" className={`nav-item ${isActive('/allocation')}`}>Asignaciones</Link>
            )}

            <Link to="/chat" className={`nav-item ${isActive('/chat')}`}>Mensajería</Link>
            <Link to="/minutes" className={`nav-item ${isActive('/minutes')}`}>Actas</Link>

            {(user.role === 'TUTOR' || user.role === 'COORDINADOR') && (
                <Link to="/alerts" className={`nav-item ${isActive('/alerts')}`}>Alertas</Link>
            )}

            <Link to="/requests" className={`nav-item ${isActive('/requests')}`}>Solicitudes</Link>

            <button onClick={logout} className="logout-btn nav-item">
                Cerrar Sesión
            </button>
        </div>
    );
}

function Home() {
    const { user } = useAuth();
    return (
        <div>
            <h1>Bienvenido, {user.name}</h1>
            <div className="grid">
                <div className="glass-panel stat-card">
                    <div style={{ flex: 1 }}>
                        <h3>Mis Tutorías</h3>
                        <p>Ver estado actual</p>
                    </div>
                </div>
                <div className="glass-panel stat-card">
                    <div style={{ flex: 1 }}>
                        <h3>Mensajes Sin Leer</h3>
                        <p>0 nuevos</p>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default function Dashboard() {
    return (
        <div className="container">
            <Sidebar />
            <div className="main-content">
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/users" element={<UserList />} />
                    <Route path="/allocation" element={<Allocation />} />
                    <Route path="/chat" element={<Chat />} />
                    <Route path="/minutes" element={<Minutes />} />
                    <Route path="/alerts" element={<Alerts />} />
                    <Route path="/requests" element={<Requests />} />
                </Routes>
            </div>
        </div>
    );
}
