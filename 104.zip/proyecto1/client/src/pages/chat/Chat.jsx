import React, { useEffect, useState, useRef } from 'react';
import io from 'socket.io-client';
import { useAuth } from '../../context/AuthContext';

const socket = io(); // Connects to same host/port by default via proxy

export default function Chat() {
    const { user } = useAuth();
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [receiverId, setReceiverId] = useState(user.role === 'ESTUDIANTE' ? user.tutorId : '');
    const [receiverName, setReceiverName] = useState('');

    const [myStudents, setMyStudents] = useState([]);

    // Update receiverId if user changes
    useEffect(() => {
        if (user.role === 'ESTUDIANTE' && user.tutorId) {
            setReceiverId(user.tutorId);
            fetch(`/api/users/name/${user.tutorId}`)
                .then(res => res.json())
                .then(data => setReceiverName(data.name))
                .catch(err => console.error("Error fetching name:", err));
        } else if (user.role === 'TUTOR') {
            fetch(`/api/data/students-by-tutor/${user.id}`)
                .then(res => res.json())
                .then(data => setMyStudents(data))
                .catch(err => console.error("Error fetching students:", err));
        }
    }, [user]);

    // Connect and join room
    useEffect(() => {
        socket.emit('join_room', user.id);

        socket.on('receive_message', (data) => {
            setMessages((prev) => [...prev, data]);
        });

        return () => socket.off('receive_message');
    }, [user.id]);

    // Load history
    useEffect(() => {
        const fetchHistory = async () => {
            // If coordinator, fetch all. If user, fetch relevant.
            // For simplicity, we fetch all and filter in UI or Endpoint.
            // Let's assume we want to chat with specific person or just see all for demo.
            const res = await fetch('/api/chat');
            const data = await res.json();
            // Filter for current user or show all if coordinator
            if (user.role === 'COORDINATOR') {
                setMessages(data);
            } else {
                setMessages(data.filter(m => m.senderId === user.id || m.receiverId === user.id));
            }
        };
        fetchHistory();
    }, [user.role, user.id]);

    const sendMessage = async () => {
        if (!input || !receiverId) return;
        const msgData = {
            senderId: user.id,
            receiverId: parseInt(receiverId),
            content: input
        };

        // Emit to server
        socket.emit('send_message', msgData);

        // Save to db via API
        await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(msgData)
        });

        // Optimistic update
        setMessages(prev => [...prev, { ...msgData, timestamp: new Date().toISOString() }]);
        setInput('');
    };

    const flagMessage = async (id) => {
        await fetch(`/api/chat/flag/${id}`, { method: 'POST' });
        // update local
        setMessages(prev => prev.map(m => m.id === id ? { ...m, isFlagged: true } : m));
    };

    return (
        <div className="chat-container glass-panel">
            <div style={{ borderBottom: '1px solid var(--border-color)', paddingBottom: '1rem', marginBottom: '1rem' }}>
                <h2>Chat en Vivo</h2>
                {user.role === 'ESTUDIANTE' ? (
                    <div style={{ color: 'var(--text-secondary)', padding: '0.5rem', background: 'var(--sidebar-bg)', borderRadius: '0.5rem', display: 'inline-block' }}>
                        Conversando con tu Tutor: <strong>{receiverName || 'Cargando...'}</strong>
                    </div>
                ) : user.role === 'TUTOR' ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <span>Conversar con:</span>
                        <select
                            value={receiverId}
                            onChange={e => setReceiverId(e.target.value)}
                            style={{ marginBottom: 0, width: 'auto' }}
                        >
                            <option value="">-- Seleccionar Alumno --</option>
                            {myStudents.map(student => (
                                <option key={student.id} value={student.id}>
                                    {student.name}
                                </option>
                            ))}
                        </select>
                    </div>
                ) : null}
            </div>

            <div className="messages-area">
                {messages.map((msg, idx) => (
                    <div key={idx} className={`message-bubble ${msg.senderId === user.id ? 'msg-sent' : 'msg-received'}`} style={{ border: msg.isFlagged ? '2px solid red' : 'none' }}>
                        <div style={{ fontSize: '0.75rem', opacity: 0.7, marginBottom: '0.2rem' }}>
                            {msg.senderId === user.id ? 'Yo' : `Usuario ${msg.senderId}`}
                        </div>
                        {msg.content}
                        {user.role === 'COORDINADOR' && !msg.isFlagged && (
                            <button
                                style={{ fontSize: '0.7rem', padding: '0.2rem 0.5rem', marginLeft: '1rem', background: 'var(--danger)' }}
                                onClick={() => flagMessage(msg.id)}
                            >
                                Marcar Inapropiado
                            </button>
                        )}
                        {msg.isFlagged && <span style={{ display: 'block', fontSize: '0.7rem', color: 'red' }}>🚩 Marcado</span>}
                    </div>
                ))}
            </div>

            {user.role !== 'COORDINADOR' && (
                <div className="chat-input-area">
                    <input
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        placeholder="Escribe un mensaje..."
                        onKeyDown={e => e.key === 'Enter' && sendMessage()}
                    />
                    <button onClick={sendMessage}>Enviar</button>
                </div>
            )}
        </div>
    );
}
