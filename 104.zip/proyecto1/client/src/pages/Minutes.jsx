import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Minutes() {
    const { user } = useAuth();
    const [minutes, setMinutes] = useState([]);
    const [form, setForm] = useState({ studentId: '', description: '', date: '' });

    useEffect(() => {
        fetchMinutes();
    }, []);

    const fetchMinutes = async () => {
        const res = await fetch('/api/minutes');
        const data = await res.json();
        setMinutes(data);
    };

    const createMinute = async (e) => {
        e.preventDefault();
        await fetch('/api/minutes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...form, tutorId: user.id })
        });
        fetchMinutes();
        setForm({ studentId: '', description: '', date: '' });
    };

    const downloadCSV = () => {
        const csvContent = "data:text/csv;charset=utf-8,"
            + "ID,TutorID,StudentID,Date,Description\n"
            + minutes.map(e => `${e.id},${e.tutorId},${e.studentId},${e.date},${e.description}`).join("\n");
        const encodedUri = encodeURI(csvContent);
        window.open(encodedUri);
    };

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <h1>Actas de Tutoría</h1>
                {user.role === 'COORDINADOR' && <button onClick={downloadCSV}>Exportar CSV</button>}
            </div>

            {user.role === 'TUTOR' && (
                <div className="glass-panel">
                    <h3>Nueva Acta</h3>
                    <form onSubmit={createMinute}>
                        <input placeholder="ID Alumno" value={form.studentId} onChange={e => setForm({ ...form, studentId: e.target.value })} />
                        <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} />
                        <textarea placeholder="Descripción de la sesión..." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3}></textarea>
                        <button type="submit">Guardar Acta</button>
                    </form>
                </div>
            )}

            <div className="glass-panel">
                {minutes.map(m => (
                    <div key={m.id} style={{ borderBottom: '1px solid var(--border-color)', padding: '1rem 0' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                            <strong>Fecha: {m.date}</strong>
                            <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Tutor: {m.tutorId} | Alumno: {m.studentId}</span>
                        </div>
                        <p>{m.description}</p>
                    </div>
                ))}
                {minutes.length === 0 && <p>No hay actas registradas.</p>}
            </div>
        </div>
    );
}
