import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';

export default function UserList() {
    const { user } = useAuth();
    const [users, setUsers] = useState([]);
    const [searchDni, setSearchDni] = useState('');
    const [formData, setFormData] = useState({ name: '', email: '', dni: '', role: 'ESTUDIANTE', password: '123' });

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        const res = await fetch('/api/users');
        const data = await res.json();
        setUsers(data);
    };

    const handleSearch = async () => {
        if (!searchDni) {
            fetchUsers();
            return;
        }
        const res = await fetch(`/api/users/${searchDni}`);
        if (res.ok) {
            const data = await res.json();
            setUsers([data]);
        } else {
            setUsers([]);
        }
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        await fetch('/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        fetchUsers();
        setFormData({ name: '', email: '', dni: '', role: 'ESTUDIANTE', password: '123' });
    };

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h1>Gestión de Usuarios</h1>
                {user.role === 'TUTOR' && (
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                        <input
                            placeholder="Buscar por DNI"
                            value={searchDni}
                            onChange={e => setSearchDni(e.target.value)}
                            style={{ marginBottom: 0 }}
                        />
                        <button onClick={handleSearch}>Buscar</button>
                    </div>
                )}
            </div>

            {user.role === 'COORDINADOR' && (
                <div className="glass-panel">
                    <h3>Crear Nuevo Usuario</h3>
                    <form onSubmit={handleCreate} style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                        <input placeholder="Nombre" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
                        <input placeholder="Email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} />
                        <input placeholder="DNI" value={formData.dni} onChange={e => setFormData({ ...formData, dni: e.target.value })} />
                        <select value={formData.role} onChange={e => setFormData({ ...formData, role: e.target.value })}>
                            <option value="ESTUDIANTE">Alumno</option>
                            <option value="TUTOR">Tutor</option>
                            <option value="COORDINADOR">Coordinador</option>
                        </select>
                        <button type="submit">Crear</button>
                    </form>
                </div>
            )}

            <div className="glass-panel">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>DNI</th>
                            <th>Rol</th>
                            <th>Tutor ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.length > 0 ? users.map(u => (
                            <tr key={u.id}>
                                <td>{u.id}</td>
                                <td>{u.name}</td>
                                <td>{u.email}</td>
                                <td>{u.dni}</td>
                                <td>
                                    <span className={`badge badge-${u.role.toLowerCase()}`}>{u.role}</span>
                                </td>
                                <td>{u.tutorId || '-'}</td>
                            </tr>
                        )) : <tr><td colSpan="6" style={{ textAlign: 'center' }}>No encontrados</td></tr>}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
