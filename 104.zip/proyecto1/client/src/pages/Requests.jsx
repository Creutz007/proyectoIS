import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Requests() {
    const { user } = useAuth();
    const [requests, setRequests] = useState([]);
    const [form, setForm] = useState({ recipientId: '', requestedTime: '' });

    useEffect(() => {
        fetchRequests();
    }, []);

    const fetchRequests = async () => {
        const res = await fetch(`/api/requests?userId=${user.id}`);
        const data = await res.json();
        setRequests(data);
    };

    const createRequest = async (e) => {
        e.preventDefault();
        await fetch('/api/requests', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...form, requesterId: user.id })
        });
        fetchRequests();
    };

    return (
        <div>
            <h1>Solicitudes de Tutoría</h1>

            <div className="glass-panel">
                <h3>Nueva Solicitud</h3>
                <form onSubmit={createRequest} style={{ display: 'flex', gap: '1rem' }}>
                    <input placeholder="ID Destinatario" value={form.recipientId} onChange={e => setForm({ ...form, recipientId: e.target.value })} />
                    <input type="datetime-local" value={form.requestedTime} onChange={e => setForm({ ...form, requestedTime: e.target.value })} />
                    <button type="submit">Solicitar</button>
                </form>
            </div>

            <div className="glass-panel">
                <h3>Historial</h3>
                <ul>
                    {requests.map(r => (
                        <li key={r.id} style={{ padding: '0.5rem', borderBottom: '1px solid var(--border-color)' }}>
                            {r.status === 'PENDING' ? '⏳' : '✅'}
                            <strong> {new Date(r.requestedTime).toLocaleString()}</strong>
                            {' - '}
                            {r.requesterId === user.id ? `Solicitado a ${r.recipientId}` : `Recibido de ${r.requesterId}`}
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}
