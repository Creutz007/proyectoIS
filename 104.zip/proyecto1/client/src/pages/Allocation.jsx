import React, { useState } from 'react';

export default function Allocation() {
    const [message, setMessage] = useState('');

    const runAuto = async () => {
        const res = await fetch('/api/allocations/auto', { method: 'POST' });
        const data = await res.json();
        setMessage(data.message || data.error);
    };

    const [manualData, setManual] = useState({ studentId: '', tutorId: '' });
    const runManual = async (e) => {
        e.preventDefault();
        const res = await fetch('/api/allocations/manual', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(manualData)
        });
        const data = await res.json();
        setMessage(data.message || data.error);
    };

    return (
        <div>
            <h1>Asignación de Tutorías</h1>
            {message && <div style={{ padding: '1rem', background: 'var(--accent)', borderRadius: '0.5rem', marginBottom: '1rem' }}>{message}</div>}

            <div className="grid">
                <div className="glass-panel">
                    <h3>Asignación Automática</h3>
                    <p>Distribuye equitativamente a todos los alumnos sin tutor entre los tutores disponibles.</p>
                    <button onClick={runAuto}>Ejecutar Asignación Auto</button>
                </div>

                <div className="glass-panel">
                    <h3>Asignación Manual</h3>
                    <form onSubmit={runManual}>
                        <input placeholder="ID Alumno" value={manualData.studentId} onChange={e => setManual({ ...manualData, studentId: e.target.value })} />
                        <input placeholder="ID Tutor" value={manualData.tutorId} onChange={e => setManual({ ...manualData, tutorId: e.target.value })} />
                        <button type="submit">Asignar</button>
                    </form>
                </div>
            </div>
        </div>
    );
}
