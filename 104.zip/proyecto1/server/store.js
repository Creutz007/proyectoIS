const store = {
    users: [
        { id: 1, name: "Andrés Barrera Jiménez", email: "anbaji@uni.edu", password: "123", dni: "00000000A", role: "COORDINADOR" },
        { id: 2, name: "Sofía Ábalos García", email: "sofiaag@uni.edu", password: "123", dni: "11111111B", role: "TUTOR" },
        { id: 3, name: "Jorge García López", email: "jorgagl@uni.edu", password: "123", dni: "22222222C", role: "TUTOR" },
        { id: 4, name: "Elena García López", email: "elenagl@uni.edu", password: "123", dni: "33333333D", role: "ESTUDIANTE", tutorId: 2 },
        { id: 5, name: "María García López", email: "marialgl@uni.edu", password: "123", dni: "44444444E", role: "ESTUDIANTE", tutorId: 2 },
        { id: 6, name: "Luis García López", email: "luisgl@uni.edu", password: "123", dni: "55555555F", role: "ESTUDIANTE", tutorId: null },
    ],
    allocations: [
        // Represented by tutorId in user object, but we can keep logic here if needed.
        // For now, straightforward relation.
    ],
    requests: [
        { id: 1, requesterId: 4, recipientId: 2, status: 'PENDING', requestedTime: '2025-12-20T10:00:00', createdAt: new Date().toISOString() }
    ],
    minutes: [
        // { id, tutorId, studentId, date, description, createdAt }
    ],
    messages: [
        // { id, senderId, receiverId, content, timestamp, isFlagged }
        { id: 1, senderId: 4, receiverId: 2, content: "Hola profesor, tengo duda.", timestamp: new Date().toISOString(), isFlagged: false }
    ],
    alerts: [
        // { id, tutorId, studentId, type, description, createdAt }
    ]
};

let idCounters = {
    users: 7,
    requests: 2,
    minutes: 1,
    messages: 2,
    alerts: 1
};

module.exports = { store, idCounters };
