const request = require('supertest');
const { app } = require('../server');
const { store, resetStore } = require('../store');

describe('University System Tests', () => {

    beforeEach(() => {
        resetStore();
    });

    test('TestAsignacionEquitativa: verifica Que los alumnos se repartan por igual entre tutores', async () => {
        // Setup: Clear existing users and add specific ones for this test
        store.users = [];
        store.users.push(
            { id: 101, role: 'TUTOR', name: 'T1' },
            { id: 102, role: 'TUTOR', name: 'T2' },
            { id: 201, role: 'ESTUDIANTE', tutorId: null },
            { id: 202, role: 'ESTUDIANTE', tutorId: null },
            { id: 203, role: 'ESTUDIANTE', tutorId: null },
            { id: 204, role: 'ESTUDIANTE', tutorId: null }
        );

        const res = await request(app).post('/api/allocations/auto');
        expect(res.statusCode).toEqual(200);

        const students = store.users.filter(u => u.role === 'ESTUDIANTE');
        const countT1 = students.filter(s => s.tutorId === 101).length;
        const countT2 = students.filter(s => s.tutorId === 102).length;

        expect(countT1).toEqual(2);
        expect(countT2).toEqual(2);
    });

    test('TestListaEsperaSinTutores: verifica Que si no hay tutores, el alumno quede en lista de espera', async () => {
        store.users = [
            { id: 201, role: 'ESTUDIANTE', tutorId: null }
        ];

        const res = await request(app).post('/api/allocations/auto');

        // As per current logic, it returns 400 if no tutors
        expect(res.statusCode).toEqual(400);
        expect(store.users[0].tutorId).toBeNull();
    });

    test('TestAlertaUsoIndebido: verifica Que al 3er mensaje indebido se dispare la alerta', async () => {
        const studentId = 999;
        store.messages = [
            { id: 10, senderId: studentId, isFlagged: false },
            { id: 11, senderId: studentId, isFlagged: false },
            { id: 12, senderId: studentId, isFlagged: false }
        ];
        store.alerts = [];

        // Flag 1st
        await request(app).post('/api/chat/flag/10');
        expect(store.alerts.length).toBe(0);

        // Flag 2nd
        await request(app).post('/api/chat/flag/11');
        expect(store.alerts.length).toBe(0);

        // Flag 3rd
        await request(app).post('/api/chat/flag/12');
        expect(store.alerts.length).toBe(1);
        expect(store.alerts[0].type).toBe('USO_INDEBIDO');
    });

    test('TestReemplazoTutor: verifica Que al reasignar un alumno, el tutor viejo se borre y el nuevo se guarde', async () => {
        store.users = [
            { id: 101, role: 'TUTOR' },
            { id: 102, role: 'TUTOR' },
            { id: 201, role: 'ESTUDIANTE', tutorId: 101 }
        ];

        const res = await request(app).post('/api/allocations/manual').send({
            studentId: 201,
            tutorId: 102
        });

        expect(res.statusCode).toEqual(200);
        const student = store.users.find(u => u.id === 201);
        expect(student.tutorId).toBe(102);
    });

    test('TestBusquedaDNIFallida: verifica Que el sistema avise correctamente si un DNI no existe', async () => {
        store.users = [{ dni: 'EXISTING_DNI', role: 'ESTUDIANTE' }];

        const res = await request(app).get('/api/users/NON_EXISTENT_DNI');
        expect(res.statusCode).toEqual(404);
        expect(res.body.error).toBeDefined();
    });

    test('TestGuardarActaExitoso: verifica Que los datos del acta (fecha, motivo) se guarden correctamente', async () => {
        store.minutes = [];
        const minuteData = {
            tutorId: 101,
            studentId: 201,
            description: 'Reunión de seguimiento',
            date: '2025-12-25'
        };

        const res = await request(app).post('/api/minutes').send(minuteData);
        expect(res.statusCode).toEqual(200);

        expect(store.minutes.length).toBe(1);
        expect(store.minutes[0].description).toBe(minuteData.description);
        expect(store.minutes[0].date).toBe(minuteData.date);
    });

});
