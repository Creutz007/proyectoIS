const express = require('express');
const router = express.Router();
const { store, idCounters } = require('./store');

// --- Helpers ---
const getUser = (id) => store.users.find(u => u.id === parseInt(id));

// --- Auth ---
router.post('/auth/login', (req, res) => {
    const { email, password } = req.body;
    const user = store.users.find(u => u.email === email && u.password === password);
    if (user) {
        const { password, ...userWithoutPass } = user;
        res.json(userWithoutPass);
    } else {
        res.status(401).json({ error: "Credenciales inválidas" });
    }
});

// --- Users (Coord only mostly, but accessible for demo) ---
router.get('/users', (req, res) => {
    const { role } = req.query;
    if (role) {
        return res.json(store.users.filter(u => u.role === role));
    }
    res.json(store.users);
});

router.post('/users', (req, res) => {
    const { name, email, role, dni, password } = req.body;
    const newUser = {
        id: idCounters.users++,
        name, email, role, dni, password,
        tutorId: null // default
    };
    store.users.push(newUser);
    res.json(newUser);
});

router.get('/users/:dni', (req, res) => {
    const user = store.users.find(u => u.dni === req.params.dni);
    if (user) res.json(user);
    else res.status(404).json({ error: "Usuario no encontrado" });
});

// --- Allocation ---
// Auto assign
router.post('/allocations/auto', (req, res) => {
    const students = store.users.filter(u => u.role === 'ESTUDIANTE');
    const tutors = store.users.filter(u => u.role === 'TUTOR');

    if (tutors.length === 0) return res.status(400).json({ error: "No hay tutores" });

    // Round robin assignment
    let tutorIndex = 0;
    students.forEach(s => {
        s.tutorId = tutors[tutorIndex].id;
        tutorIndex = (tutorIndex + 1) % tutors.length;
    });

    res.json({ message: "Asignación automática completada", students });
});

// Manual assign
router.post('/allocations/manual', (req, res) => {
    const { studentId, tutorId } = req.body; // Ids
    const student = store.users.find(u => u.id === parseInt(studentId));
    if (student) {
        student.tutorId = parseInt(tutorId);
        res.json({ message: "Asignado correctamente", student });
    } else {
        res.status(404).json({ error: "Alumno no encontrado" });
    }
});

// --- Requests ---
router.get('/requests', (req, res) => {
    // Optionally filter by user
    const { userId } = req.query;
    if (userId) {
        return res.json(store.requests.filter(r => r.requesterId == userId || r.recipientId == userId));
    }
    res.json(store.requests);
});

router.post('/requests', (req, res) => {
    const { requesterId, recipientId, requestedTime } = req.body;
    const newReq = {
        id: idCounters.requests++,
        requesterId, recipientId, status: 'PENDING', requestedTime, createdAt: new Date().toISOString()
    };
    store.requests.push(newReq);
    res.json(newReq);
});

// --- Minutes (Actas) ---
router.get('/minutes', (req, res) => {
    res.json(store.minutes);
});

router.post('/minutes', (req, res) => {
    const { tutorId, studentId, description, date } = req.body;
    const newMin = {
        id: idCounters.minutes++,
        tutorId, studentId, description, date, createdAt: new Date().toISOString()
    };
    store.minutes.push(newMin);
    res.json(newMin);
});

// --- Chat ---
router.get('/chat', (req, res) => {
    const { user1, user2 } = req.query;
    if (user1 && user2) {
        // Conversation between two people
        const msgs = store.messages.filter(m =>
            (m.senderId == user1 && m.receiverId == user2) ||
            (m.senderId == user2 && m.receiverId == user1)
        );
        return res.json(msgs);
    }
    // Supervisor view (all messages or filtered)
    res.json(store.messages);
});

router.post('/chat', (req, res) => {
    const { senderId, receiverId, content } = req.body;
    const msg = {
        id: idCounters.messages++,
        senderId, receiverId, content, timestamp: new Date().toISOString(), isFlagged: false
    };
    store.messages.push(msg);
    // Realtime is handled via socket in client, but we assume persistence here.
    res.json(msg);
});

router.post('/chat/flag/:id', (req, res) => {
    const msg = store.messages.find(m => m.id == req.params.id);
    if (msg) {
        msg.isFlagged = true;

        // Verifica si es el 3er mensaje indebido
        const flaggedCount = store.messages.filter(m => m.senderId === msg.senderId && m.isFlagged).length;
        if (flaggedCount === 3) {
            const alert = {
                id: idCounters.alerts++,
                tutorId: null, // Podría buscarse el tutor del alumno
                studentId: msg.senderId,
                type: 'USO_INDEBIDO',
                description: 'El alumno ha acumulado 3 mensajes indebidos.',
                createdAt: new Date().toISOString()
            };
            store.alerts.push(alert);
        }

        res.json(msg);
    } else {
        res.status(404).json({ error: "Mensaje no encontrado" });
    }
});

// --- Alerts ---
router.get('/alerts', (req, res) => {
    res.json(store.alerts);
});

router.post('/alerts', (req, res) => {
    const { tutorId, studentId, type, description } = req.body;
    const alert = {
        id: idCounters.alerts++,
        tutorId, studentId, type, description, createdAt: new Date().toISOString()
    };
    store.alerts.push(alert);
    res.json(alert);
});

// Stats or Data aggregation
router.get('/data/students-by-tutor/:tutorId', (req, res) => {
    const students = store.users.filter(u => u.role === 'ESTUDIANTE' && u.tutorId == req.params.tutorId);
    res.json(students);
});

router.get('/users/name/:id', (req, res) => {
    const user = store.users.find(u => u.id == req.params.id);
    if (user) res.json({ name: user.name });
    else res.json({ name: `Usuario ${req.params.id}` });
});

module.exports = router;
