const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require("socket.io");
const routes = require('./routes');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*", // Allow all for dev
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(express.json());

// Inject io into request for real-time notifications if needed
app.use((req, res, next) => {
    req.io = io;
    next();
});

// API Routes
app.use('/api', routes);

// Socket.io for Chat
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join_room', (userId) => {
        socket.join(userId.toString()); // Users join room by their ID
    });

    socket.on('send_message', (data) => {
        // data: { senderId, receiverId, content }
        // Broadcast to receiver
        io.to(data.receiverId.toString()).emit('receive_message', data);
        // Also back to sender for optimistic UI if needed (though usually handled by client)
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

const PORT = 3001;

if (require.main === module) {
    server.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
    });
}

module.exports = { app, server };
